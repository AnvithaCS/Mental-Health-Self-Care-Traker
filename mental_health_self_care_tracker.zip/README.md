
# Mental Health Self-Care Tracker

This project is a simple UI concept for a daily mental health tracker app. It is designed to help users reflect on their mental well-being, track habits, and build a consistent self-care routine.

---

## 🧠 Features

- **Mood Check-In**  
  Select your daily mood using emojis or tags (Happy, Sad, Anxious, Excited, etc.)

- **Gratitude Journal**  
  Write one thing you’re thankful for each day.

- **Energy Level Slider**  
  Rate your energy on a scale from 1–10.

- **Daily Habits Tracker**  
  Mark completion of self-care habits like:
  - Sleep
  - Hydration
  - Meditation
  - Exercise
  - Reduced screen time

- **Daily Affirmation**  
  Motivational quotes to start the day with positivity.

- **Mood History View**  
  A calendar-style visual showing mood patterns over time.

---

## 🛠 Tools Used

- **Canva** – for designing the UI layout
- No code (design-only concept project)

---

## 🖼️ Preview

![Mental Health Self-Care UI](A_2D_digital_design_of_a_mental_health_self-care_t.png)

---

## 📌 Author

**C S Anvitha**  
2nd Sem B.Tech ECE @ PES University  
This project is part of my application for an internship at **cHEAL**, PES University, with an interest in mental health technology and assistive interfaces.
